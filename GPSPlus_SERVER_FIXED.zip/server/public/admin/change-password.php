<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';
session_name($config['session_name']);
session_start([
    'cookie_httponly' => true,
    'cookie_samesite' => 'Strict',
    'cookie_secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'use_strict_mode' => true,
]);
if (empty($_SESSION['admin']) || empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
$_SESSION['csrf'] = $_SESSION['csrf'] ?? bin2hex(random_bytes(32));
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = (string)($_POST['current_password'] ?? '');
    $new = (string)($_POST['new_password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');

    if (!hash_equals((string)$_SESSION['csrf'], (string)($_POST['csrf'] ?? ''))) {
        $error = 'تعذر التحقق من الطلب.';
    } elseif (strlen($new) < 8) {
        $error = 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل.';
    } elseif ($new !== $confirm) {
        $error = 'تأكيد كلمة المرور غير مطابق.';
    } else {
        $stmt = $db->prepare('SELECT password_hash FROM admin_users WHERE id = ?');
        $stmt->execute([(int)$_SESSION['admin_id']]);
        $hash = (string)$stmt->fetchColumn();
        if (!$hash || !password_verify($current, $hash)) {
            $error = 'كلمة المرور الحالية غير صحيحة.';
        } else {
            $stmt = $db->prepare('UPDATE admin_users SET password_hash = ?, updated_at = ? WHERE id = ?');
            $stmt->execute([password_hash($new, PASSWORD_DEFAULT), date('Y-m-d H:i:s'), (int)$_SESSION['admin_id']]);
            log_admin_event($db, (string)$_SESSION['admin_username'], 'password_changed');
            $message = 'تم تغيير كلمة المرور بنجاح.';
        }
    }
}
?><!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="../assets/style.css"><title>تغيير كلمة المرور</title></head><body><main class="page"><section class="card"><div class="topbar"><h1>تغيير كلمة المرور</h1><a class="btn" href="index.php">رجوع</a></div><?php if ($message): ?><div class="result success"><?=htmlspecialchars($message, ENT_QUOTES, 'UTF-8')?></div><?php endif; ?><?php if ($error): ?><div class="result error"><?=htmlspecialchars($error, ENT_QUOTES, 'UTF-8')?></div><?php endif; ?><form method="post" class="stack"><input type="hidden" name="csrf" value="<?=htmlspecialchars((string)$_SESSION['csrf'], ENT_QUOTES, 'UTF-8')?>"><input type="password" name="current_password" placeholder="كلمة المرور الحالية" required><input type="password" name="new_password" placeholder="كلمة المرور الجديدة" minlength="8" required><input type="password" name="confirm_password" placeholder="تأكيد كلمة المرور" minlength="8" required><button type="submit">حفظ كلمة المرور</button></form></section></main></body></html>
