<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';
session_name($config['session_name']);
session_start();
if (!empty($_SESSION['admin_username'])) {
    log_admin_event($db, (string)$_SESSION['admin_username'], 'logout');
}
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], (bool)$params['secure'], (bool)$params['httponly']);
}
session_destroy();
header('Location: login.php');
exit;
