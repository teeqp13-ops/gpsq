<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';

session_name($config['session_name']);
session_start([
    'cookie_httponly' => true,
    'cookie_samesite' => 'Strict',
    'cookie_secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'use_strict_mode' => true,
]);

if (!empty($_SESSION['admin'])) {
    header('Location: index.php');
    exit;
}

$error = '';
$_SESSION['csrf'] = $_SESSION['csrf'] ?? bin2hex(random_bytes(32));
$_SESSION['login_attempts'] = $_SESSION['login_attempts'] ?? [];
$_SESSION['login_attempts'] = array_values(array_filter(
    $_SESSION['login_attempts'],
    static fn($timestamp): bool => (int)$timestamp > time() - 900
));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    if (count($_SESSION['login_attempts']) >= 5) {
        $error = 'تم إيقاف المحاولات مؤقتًا. حاول بعد 15 دقيقة.';
        log_admin_event($db, $username ?: '-', 'blocked');
    } elseif (!hash_equals((string)$_SESSION['csrf'], (string)($_POST['csrf'] ?? ''))) {
        $error = 'انتهت الجلسة، أعد المحاولة.';
        log_admin_event($db, $username ?: '-', 'csrf_failed');
    } else {
        $stmt = $db->prepare('SELECT * FROM admin_users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, (string)$admin['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin'] = true;
            $_SESSION['admin_id'] = (int)$admin['id'];
            $_SESSION['admin_username'] = (string)$admin['username'];
            $_SESSION['login_attempts'] = [];
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            log_admin_event($db, $username, 'login_success');
            header('Location: index.php');
            exit;
        }

        $_SESSION['login_attempts'][] = time();
        $error = 'بيانات الدخول غير صحيحة';
        log_admin_event($db, $username ?: '-', 'login_failed');
    }
}
?><!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="../assets/style.css"><title>دخول الإدارة</title></head>
<body><main class="page"><section class="card"><h1>دخول الإدارة</h1><?php if ($error): ?><div class="result error"><?=htmlspecialchars($error, ENT_QUOTES, 'UTF-8')?></div><?php endif; ?><form method="post" class="stack"><input type="hidden" name="csrf" value="<?=htmlspecialchars((string)$_SESSION['csrf'], ENT_QUOTES, 'UTF-8')?>"><input name="username" placeholder="اسم المستخدم" autocomplete="username" required><input type="password" name="password" placeholder="كلمة المرور" autocomplete="current-password" required><button type="submit">دخول</button></form></section></main></body></html>
