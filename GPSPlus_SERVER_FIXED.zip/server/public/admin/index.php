<?php
declare(strict_types=1);
$config=require dirname(__DIR__).'/config.php';
session_name($config['session_name']);
session_start(['cookie_httponly'=>true,'cookie_samesite'=>'Strict','cookie_secure'=>!empty($_SERVER['HTTPS'])]);
if(empty($_SESSION['admin'])){header('Location:login.php');exit;}
require dirname(__DIR__,2).'/app/bootstrap.php';
$_SESSION['csrf']=$_SESSION['csrf']??bin2hex(random_bytes(32));
$message='';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!hash_equals((string)$_SESSION['csrf'],(string)($_POST['csrf']??''))){$error='انتهت الجلسة، أعد المحاولة.';}
 else {
  $action=(string)($_POST['action']??'create');
  if($action==='create'){
   $count=max(1,min(200,(int)($_POST['count']??1)));
   $days=(int)($_POST['days']??30); if(!in_array($days,[30,365],true))$days=30;
   $stmt=$db->prepare('INSERT INTO licenses(code,duration_days,status,created_at) VALUES(?,?,?,?)');
   $created=[];for($i=0;$i<$count;$i++){do{$code=generate_code(16);$c=$db->prepare('SELECT 1 FROM licenses WHERE code=?');$c->execute([$code]);}while($c->fetchColumn());$stmt->execute([$code,$days,'active',date('Y-m-d H:i:s')]);$created[]=$code;}
   $_SESSION['created_codes']=$created;$message="تم إنشاء {$count} كود لمدة {$days} يوم";
  }
 }
}
$q=trim((string)($_GET['q']??''));$filter=(string)($_GET['filter']??'all');
$sql='SELECT * FROM licenses WHERE 1=1';$params=[];
if($q!==''){$sql.=' AND (code LIKE ? OR device_uuid LIKE ?)';$params[]='%'.$q.'%';$params[]='%'.$q.'%';}
if($filter==='used')$sql.=' AND activated_at IS NOT NULL';
elseif($filter==='unused')$sql.=' AND activated_at IS NULL';
elseif($filter==='expired')$sql.=" AND expires_at IS NOT NULL AND datetime(expires_at) < datetime('now','localtime')";
$sql.=' ORDER BY id DESC LIMIT 500';$s=$db->prepare($sql);$s->execute($params);$rows=$s->fetchAll();
$stats=[
 'total'=>(int)$db->query('SELECT COUNT(*) FROM licenses')->fetchColumn(),
 'used'=>(int)$db->query('SELECT COUNT(*) FROM licenses WHERE activated_at IS NOT NULL')->fetchColumn(),
 'unused'=>(int)$db->query('SELECT COUNT(*) FROM licenses WHERE activated_at IS NULL')->fetchColumn(),
 'active'=>(int)$db->query("SELECT COUNT(*) FROM licenses WHERE status='active' AND (expires_at IS NULL OR datetime(expires_at)>=datetime('now','localtime'))")->fetchColumn(),
];
function h(?string $v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function state(array $r):array{if($r['status']!=='active')return ['موقوف','bad'];if($r['expires_at']&&strtotime($r['expires_at'])<time())return ['منتهي','bad'];if($r['activated_at'])return ['مستخدم','ok'];return ['غير مستخدم','warn'];}
$createdCodes=$_SESSION['created_codes']??[];unset($_SESSION['created_codes']);
?><!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="../assets/style.css"><title>لوحة GPS Plus</title></head><body>
<div class="admin-shell"><aside class="sidebar"><div class="brand">GPS<span>Plus</span></div><a class="nav active" href="index.php">لوحة الأكواد</a><a class="nav" href="reset-code.php">ترسيت الكود</a><a class="nav" href="binding.php">ربط الأجهزة</a><a class="nav" href="change-password.php">كلمة المرور</a><a class="nav danger-link" href="logout.php">تسجيل الخروج</a></aside>
<main class="content"><div class="page-head"><div><h1>إدارة الأكواد</h1><p>إنشاء، فحص ومتابعة أكواد الاشتراك</p></div></div>
<?php if($message):?><div class="alert success"><?=h($message)?></div><?php endif;?><?php if($createdCodes):?><section class="panel generated-box"><div class="panel-title"><h2>الأكواد الجديدة</h2><button type="button" class="copy-all" onclick="copyText(document.getElementById('createdCodes').value,this)">نسخ جميع الأكواد</button></div><textarea id="createdCodes" readonly><?=h(implode("\n",$createdCodes))?></textarea></section><?php endif;?><?php if($error):?><div class="alert error"><?=h($error)?></div><?php endif;?>
<div class="stats"><div class="stat"><b><?=$stats['total']?></b><span>إجمالي الأكواد</span></div><div class="stat"><b><?=$stats['used']?></b><span>مستخدمة</span></div><div class="stat"><b><?=$stats['unused']?></b><span>غير مستخدمة</span></div><div class="stat"><b><?=$stats['active']?></b><span>فعّالة</span></div></div>
<section class="panel"><h2>إنشاء أكواد جديدة</h2><form method="post" class="create-grid"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="create"><label>العدد<input type="number" name="count" value="1" min="1" max="200"></label><label>المدة<select name="days"><option value="30">30 يوم</option><option value="365">365 يوم</option></select></label><button>إنشاء الأكواد</button></form></section>
<section class="panel"><div class="panel-title"><h2>قائمة الأكواد</h2><form class="filters"><input name="q" value="<?=h($q)?>" placeholder="ابحث بالكود أو معرف الجهاز"><select name="filter"><option value="all">الكل</option><option value="used" <?=$filter==='used'?'selected':''?>>مستخدم</option><option value="unused" <?=$filter==='unused'?'selected':''?>>غير مستخدم</option><option value="expired" <?=$filter==='expired'?'selected':''?>>منتهي</option></select><button>بحث</button></form></div><div class="table-wrap"><table><thead><tr><th>الكود</th><th>نسخ</th><th>المدة</th><th>الحالة</th><th>ربط السورس</th><th>معرف الجهاز</th><th>تاريخ الاستخدام</th><th>تاريخ الانتهاء</th><th>آخر اتصال</th></tr></thead><tbody><?php foreach($rows as $r):[$label,$cls]=state($r);?><tr class="row-<?=$cls?>"><td><code id="code-<?=intval($r['id'])?>"><?=h($r['code'])?></code></td><td><button type="button" class="copy-btn" onclick="copyText(document.getElementById('code-<?=intval($r['id'])?>').innerText,this)">نسخ</button></td><td><span class="duration duration-<?=intval($r['duration_days'])?>"><?=intval($r['duration_days'])?> يوم</span></td><td><span class="badge <?=$cls?>"><?=$label?></span></td><td><span class="badge <?=!empty($r['source_id'])?'ok':'warn'?>"><?=!empty($r['source_id'])?'مرتبط مرة واحدة':'غير مرتبط'?></span><small class="source-id"><?=h($r['source_id']?:'')?></small></td><td class="mono"><?=h($r['device_uuid']?:'-')?></td><td><?=h($r['activated_at']?:'-')?></td><td><?=h($r['expires_at']?:'-')?></td><td><?=h($r['last_seen_at']?:'-')?></td></tr><?php endforeach;?><?php if(!$rows):?><tr><td colspan="9" class="empty">لا توجد نتائج</td></tr><?php endif;?></tbody></table></div></section>
</main></div><script>async function copyText(text,btn){try{await navigator.clipboard.writeText(text);const old=btn.textContent;btn.textContent='تم النسخ';btn.classList.add('copied');setTimeout(()=>{btn.textContent=old;btn.classList.remove('copied')},1200)}catch(e){prompt('انسخ النص:',text)}}</script></body></html>
