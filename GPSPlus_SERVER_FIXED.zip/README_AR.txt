ارفع مجلد server كاملًا داخل public_html بحيث يصبح الرابط:
https://ipa.p3nd.fun/server/public/

1) اجعل صلاحية server/storage = 755 أو 775 حسب الاستضافة.
2) تأكد من تفعيل PHP PDO_SQLite.
3) غيّر CHANGE_THIS_API_KEY في server/app/config.php أو عرّف متغير البيئة GPS_API_KEY.
4) افتح /server/public/health.php أولًا.
5) إذا كانت الحالة ok افتح /server/public/install.php.
6) دخول الإدارة: /server/public/admin/login.php
اسم المستخدم admin وكلمة المرور المؤقتة 123456.
